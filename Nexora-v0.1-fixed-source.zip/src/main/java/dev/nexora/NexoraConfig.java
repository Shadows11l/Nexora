package dev.nexora;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class NexoraConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("nexora.json");
    public boolean keystrokes = true;
    public boolean customCrosshair = false;
    public boolean hitParticles = true;

    public static NexoraConfig load() {
        try {
            if (Files.exists(FILE)) {
                NexoraConfig config = GSON.fromJson(Files.readString(FILE), NexoraConfig.class);
                if (config != null) return config;
            }
        } catch (Exception ignored) {}
        return new NexoraConfig();
    }

    public void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(this));
        } catch (IOException ignored) {}
    }
}
