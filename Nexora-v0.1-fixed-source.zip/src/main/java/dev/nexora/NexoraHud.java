package dev.nexora;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public final class NexoraHud {
    private NexoraHud() {}

    public static void register() {
        HudRenderCallback.EVENT.register((context, tickCounter) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player == null || client.options.hudHidden) return;
            NexoraConfig cfg = NexoraClient.config;
            if (cfg == null) return;
            if (cfg.keystrokes) drawKeys(context, client);
            if (cfg.customCrosshair) drawCrosshair(context, client);
        });
    }

    private static void drawKeys(DrawContext ctx, MinecraftClient client) {
        int x = 10, y = 35, size = 18, gap = 2;
        key(ctx, client, "W", x + size + gap, y);
        key(ctx, client, "A", x, y + size + gap);
        key(ctx, client, "S", x + size + gap, y + size + gap);
        key(ctx, client, "D", x + 2 * (size + gap), y + size + gap);
        key(ctx, client, "LMB", x, y + 2 * (size + gap), 28, client.options.attackKey.isPressed());
        key(ctx, client, "RMB", x + 30, y + 2 * (size + gap), 28, client.options.useKey.isPressed());
    }

    private static void key(DrawContext ctx, MinecraftClient client, String label, int x, int y) {
        boolean pressed = client.options.forwardKey.isPressed() && label.equals("W")
            || client.options.leftKey.isPressed() && label.equals("A")
            || client.options.backKey.isPressed() && label.equals("S")
            || client.options.rightKey.isPressed() && label.equals("D");
        key(ctx, client, label, x, y, 18, pressed);
    }

    private static void key(DrawContext ctx, MinecraftClient client, String label, int x, int y, int w, boolean pressed) {
        ctx.fill(x, y, x + w, y + 18, pressed ? 0xFF9B5CFF : 0xC8201B2B);
        ctx.drawBorder(x, y, w, 18, 0xFF6E42A6);
        ctx.drawCenteredTextWithShadow(client.textRenderer, label, x + w / 2, y + 5, 0xFFFFFFFF);
    }

    private static void drawCrosshair(DrawContext ctx, MinecraftClient client) {
        int x = client.getWindow().getScaledWidth() / 2;
        int y = client.getWindow().getScaledHeight() / 2;
        ctx.fill(x - 5, y, x + 5, y + 1, 0xFFB985FF);
        ctx.fill(x, y - 5, x + 1, y + 5, 0xFFB985FF);
    }
}
