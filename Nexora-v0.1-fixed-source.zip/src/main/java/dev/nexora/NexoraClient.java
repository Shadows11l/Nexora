package dev.nexora;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class NexoraClient implements ClientModInitializer {
    public static KeyBinding openMenuKey;
    public static NexoraConfig config;

    @Override
    public void onInitializeClient() {
        config = NexoraConfig.load();
        NexoraHud.register();
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.nexora.open_menu",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_RIGHT_SHIFT,
            KeyBinding.Category.MISC
        ));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.wasPressed()) {
                if (client.currentScreen instanceof NexoraScreen) {
                    client.setScreen(null);
                } else if (client.player != null) {
                    client.setScreen(new NexoraScreen());
                }
            }
        });
    }
}
