package dev.nexora;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class NexoraScreen extends Screen {
    private static final int PURPLE = 0xFF9B5CFF;
    private static final int PANEL = 0xE8171422;
    private NexoraConfig config;

    public NexoraScreen() {
        super(Text.literal("Nexora"));
        config = NexoraClient.config;
    }

    @Override
    protected void init() {
        int left = width / 2 - 145;
        int top = height / 2 - 95;
        addDrawableChild(ButtonWidget.builder(toggle("Keystrokes", config.keystrokes), b -> {
            config.keystrokes = !config.keystrokes;
            b.setMessage(toggle("Keystrokes", config.keystrokes));
            config.save();
        }).dimensions(left + 12, top + 48, 126, 22).build());

        addDrawableChild(ButtonWidget.builder(toggle("Custom Crosshair", config.customCrosshair), b -> {
            config.customCrosshair = !config.customCrosshair;
            b.setMessage(toggle("Custom Crosshair", config.customCrosshair));
            config.save();
        }).dimensions(left + 148, top + 48, 126, 22).build());

        addDrawableChild(ButtonWidget.builder(toggle("Hit Particles", config.hitParticles), b -> {
            config.hitParticles = !config.hitParticles;
            b.setMessage(toggle("Hit Particles", config.hitParticles));
            config.save();
        }).dimensions(left + 12, top + 76, 126, 22).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Закрыть"), b -> close())
            .dimensions(left + 148, top + 76, 126, 22).build());
    }

    private Text toggle(String name, boolean enabled) {
        return Text.literal(name + "  " + (enabled ? "§aON" : "§7OFF"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        int x = width / 2 - 145, y = height / 2 - 95;
        context.fill(x, y, x + 290, y + 132, PANEL);
        context.fill(x, y, x + 290, y + 2, PURPLE);
        context.drawText(textRenderer, "NEXORA", x + 14, y + 12, PURPLE, false);
        context.drawText(textRenderer, "D A R K   N E O N  •  v0.1", x + 14, y + 27, 0xFFB8A9CE, false);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() { return false; }
}
